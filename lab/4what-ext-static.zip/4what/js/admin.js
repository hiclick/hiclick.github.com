﻿// blank image
Ext.BLANK_IMAGE_URL = "js/extjs/3.4.1.1/resources/images/default/s.gif";

// chart
Ext.chart.Chart.CHART_URL = "js/extjs/3.4.1.1/resources/charts.swf";

// MessageBox
$ext.msg.alert(/*{
	timeout: function(o, title, msg) {
		return !title ? 1000 : false;
	}
}*/);

// tab
$ext.tab.reload("main");

// tip
Ext.QuickTips.init();
